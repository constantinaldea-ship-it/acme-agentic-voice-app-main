"""
Get branch details tool — calls the BFA Location Services API.

This Python function tool replaces the OpenAPI toolset approach by making
direct HTTP calls to the BFA Cloud Run backend for single-branch lookups.

Authentication: Uses google.auth to obtain an ID token for the Cloud Run
service, matching the serviceAgentIdTokenAuthConfig from the OpenAPI toolset.

IMPORTANT — CES Sandbox Compatibility Notes:
- Uses only Python stdlib (urllib, json) + google.auth (available in GCP)
- If google.auth is unavailable in the CES Python sandbox, falls back to
  unauthenticated requests (works when BFA auth is bypassed via feature flag)

Modified by Augment Agent on 2026-02-08
"""

import json
import urllib.request
import urllib.parse
import urllib.error


# BFA backend URL — injected from agent app.json variableDeclarations
_BACKEND_URL = "https://bfa-service-resource-1041912723804.us-central1.run.app"


def _get_id_token(target_audience: str) -> str:
    """Attempt to get a Google Cloud ID token for the target audience.

    Uses google.auth default credentials with the Cloud Run audience.
    Returns empty string if authentication libraries are not available
    (e.g., in local testing or restricted sandbox).
    """
    try:
        import google.auth.transport.requests
        import google.oauth2.id_token

        request = google.auth.transport.requests.Request()
        token = google.oauth2.id_token.fetch_id_token(request, target_audience)
        return token
    except Exception:
        # Fall back to unauthenticated — works when BFA auth bypass is enabled
        return ""


def get_branch(branchId: str) -> dict:
    """Get full details for a specific bank branch.

    Args:
        branchId: Unique branch identifier (e.g., 'DB-DE-00003').

    Returns:
        dict with 'success', 'data' (full branch details including address,
        openingHours, phone, services, accessibility), 'error', and 'meta'.
    """
    # URL-encode the branch ID for safety
    encoded_id = urllib.parse.quote(branchId, safe="")
    url = f"{_BACKEND_URL}/api/v1/branches/{encoded_id}"

    # Build request with optional auth
    req = urllib.request.Request(url, method="GET")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "CES-VoiceBankingAgent/1.0")

    token = _get_id_token(_BACKEND_URL)
    if token:
        req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8")
            return json.loads(body)
    except urllib.error.HTTPError as e:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8")
            return json.loads(error_body)
        except Exception:
            return {
                "success": False,
                "data": None,
                "error": {
                    "code": f"HTTP_{e.code}",
                    "message": error_body or str(e),
                },
            }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "data": None,
            "error": {
                "code": "CONNECTION_ERROR",
                "message": f"Failed to connect to BFA service: {e.reason}",
            },
        }
    except Exception as e:
        return {
            "success": False,
            "data": None,
            "error": {
                "code": "UNEXPECTED_ERROR",
                "message": str(e),
            },
        }
