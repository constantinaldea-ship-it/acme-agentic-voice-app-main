"""
Search branches tool — calls the BFA Location Services API.

This Python function tool replaces the OpenAPI toolset approach by making
direct HTTP calls to the BFA Cloud Run backend. It uses urllib (stdlib)
to avoid external dependency requirements in the CES sandbox.

Authentication: Uses google.auth to obtain an ID token for the Cloud Run
service, matching the serviceAgentIdTokenAuthConfig from the OpenAPI toolset.

IMPORTANT — CES Sandbox Compatibility Notes:
- Uses only Python stdlib (urllib, json) + google.auth (available in GCP)
- If google.auth is unavailable in the CES Python sandbox, falls back to
  unauthenticated requests (works when BFA auth is bypassed via feature flag)
- The $BACKEND_URL is read from the agent session variable 'backend'

Modified by Augment Agent on 2026-02-08
"""

import json
import urllib.request
import urllib.parse
import urllib.error


# BFA backend URL — injected from agent app.json variableDeclarations
_BACKEND_URL = "https://bfa-service-resource-1041912723804.us-central1.run.app"


def _get_id_token(target_audience: str) -> str:
    """Attempt to get a Google Cloud ID token for the target audience.

    Uses google.auth default credentials with the Cloud Run audience.
    Returns empty string if authentication libraries are not available
    (e.g., in local testing or restricted sandbox).
    """
    try:
        import google.auth.transport.requests
        import google.oauth2.id_token

        request = google.auth.transport.requests.Request()
        token = google.oauth2.id_token.fetch_id_token(request, target_audience)
        return token
    except Exception:
        # Fall back to unauthenticated — works when BFA auth bypass is enabled
        return ""


def search_branches(
    city: str = "",
    address: str = "",
    postalCode: str = "",
    latitude: str = "",
    longitude: str = "",
    radiusKm: str = "",
    brand: str = "",
    accessible: str = "",
    limit: str = "",
) -> dict:
    """Search for bank branches by city, address, postal code, coordinates, or brand.

    Args:
        city: City name (case-insensitive, partial match). Use German names.
        address: Street name or landmark (partial match).
        postalCode: Postal code prefix (matches start of PLZ).
        latitude: Caller latitude for distance sorting (numeric string).
        longitude: Caller longitude for distance sorting (numeric string).
        radiusKm: Search radius in km (requires lat/lon). Default 50.0.
        brand: Filter by bank brand: 'Deutsche Bank' or 'Postbank'.
        accessible: If 'true', only wheelchair-accessible branches.
        limit: Max results (max 50). Default 10.

    Returns:
        dict with 'success', 'data' (branches, count, totalMatches,
        referencePoint), 'error', and 'meta' fields.
    """
    # Build query parameters — only include non-empty values
    params = {}
    if city:
        params["city"] = city
    if address:
        params["address"] = address
    if postalCode:
        params["postalCode"] = postalCode
    if latitude:
        params["latitude"] = latitude
    if longitude:
        params["longitude"] = longitude
    if radiusKm:
        params["radiusKm"] = radiusKm
    if brand:
        params["brand"] = brand
    if accessible:
        params["accessible"] = accessible.lower()
    if limit:
        params["limit"] = limit

    # Construct URL
    query_string = urllib.parse.urlencode(params)
    url = f"{_BACKEND_URL}/api/v1/branches"
    if query_string:
        url = f"{url}?{query_string}"

    # Build request with optional auth
    req = urllib.request.Request(url, method="GET")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "CES-VoiceBankingAgent/1.0")

    token = _get_id_token(_BACKEND_URL)
    if token:
        req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8")
            return json.loads(body)
    except urllib.error.HTTPError as e:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8")
            return json.loads(error_body)
        except Exception:
            return {
                "success": False,
                "data": None,
                "error": {
                    "code": f"HTTP_{e.code}",
                    "message": error_body or str(e),
                },
            }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "data": None,
            "error": {
                "code": "CONNECTION_ERROR",
                "message": f"Failed to connect to BFA service: {e.reason}",
            },
        }
    except Exception as e:
        return {
            "success": False,
            "data": None,
            "error": {
                "code": "UNEXPECTED_ERROR",
                "message": str(e),
            },
        }
